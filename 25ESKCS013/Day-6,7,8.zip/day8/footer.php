</div>


<footer class="bg-dark text-white text-center p-3">

Student Registration System © 2026

</footer>


</body>

</html>