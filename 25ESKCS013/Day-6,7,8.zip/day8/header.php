<!DOCTYPE html>

<html>

<head>


<title>Student System</title>


<link 
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
rel="stylesheet">


<link 
rel="stylesheet" 
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">


<style>


body{

background:linear-gradient(120deg,#dbeafe,#ffffff);

}


.card{

border-radius:20px;
box-shadow:0px 5px 15px gray;

}


</style>


</head>


<body>


<nav class="navbar navbar-dark bg-primary">

<div class="container">

<h3 class="text-white">
🎓 Student Portal
</h3>

</div>

</nav>


<div class="container my-5">